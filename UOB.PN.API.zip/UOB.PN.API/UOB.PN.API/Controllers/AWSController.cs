using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SimpleNotificationService;
using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Text;

namespace UOB.PN.API.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class AWSController : ControllerBase
    {

        private readonly ILogger<AWSController> _logger;
        private IAmazonS3 _s3client { get; set; }
        private IAmazonSimpleNotificationService _snsClient { get; set; }
        private IAmazonSQS _sqsclient { get; set; }
        public AWSController(ILogger<AWSController> logger
            , IAmazonS3 s3client
            , IAmazonSimpleNotificationService snsClient
            , IAmazonSQS sqsclient)
        {
            _logger = logger;
            _s3client = s3client;
            _snsClient = snsClient;
            _sqsclient = sqsclient;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return null;
        }


        [HttpGet(Name = "SendNotification/{bucketname}/{filename}")]
        public async Task<int> GetS3File(string bucketname = "dataprosesslmdsqssns", string filename = "payload.csv")
        {
            byte[] filedata;
            if (!string.IsNullOrEmpty(bucketname))
            {
                MemoryStream ms = null;
                var file = await _s3client.GetObjectAsync(bucketname, filename);
                using (var response = await _s3client.GetObjectAsync(bucketname, filename))
                {
                    if (response.HttpStatusCode == HttpStatusCode.OK)
                    {
                        using (ms = new MemoryStream())
                        {
                            await response.ResponseStream.CopyToAsync(ms);
                        }
                    }
                }
                if (ms is null || ms.ToArray().Length < 1)
                    throw new FileNotFoundException(string.Format("The document '{0}' is not found", filename));
                filedata = ms.ToArray();


                string utfString = Encoding.UTF8.GetString(filedata, 0, filedata.Length);
                if (!string.IsNullOrEmpty(utfString))
                {
                    await Console.Out.WriteLineAsync(utfString);
                    return (int)HttpStatusCode.OK;
                }
                return (int)HttpStatusCode.NotFound;
            }
            return 1;
        }
    }
}